
import FormatAlignLeftIcon from '@material-ui/icons/FormatAlignLeft';
import FormatAlignCenterIcon from '@material-ui/icons/FormatAlignCenter';
import FormatAlignRightIcon from '@material-ui/icons/FormatAlignRight';
import FormatAlignJustifyIcon from '@material-ui/icons/FormatAlignJustify';
import FormatBoldIcon from '@material-ui/icons/FormatBold';
import FormatItalicIcon from '@material-ui/icons/FormatItalic';
import FormatUnderlinedIcon from '@material-ui/icons/FormatUnderlined';
import FormatColorFillIcon from '@material-ui/icons/FormatColorFill';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import ToggleButton from '@material-ui/lab/ToggleButton';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import ToggleButtonGroup from '@material-ui/lab/ToggleButtonGroup';  
  
  
  
  {/* <Card>
                            <CardContent>
                                <ToggleButtonGroup>
                                    <ToggleButton value={this.state.left} aria-label="left aligned">
                                        <FormatAlignLeftIcon />
                                    </ToggleButton>
                                    <ToggleButton value="center" aria-label="centered">
                                        <FormatAlignCenterIcon />
                                    </ToggleButton>
                                    <ToggleButton value="right" aria-label="right aligned">
                                        <FormatAlignRightIcon />
                                    </ToggleButton>
                                    <ToggleButton value="justify" aria-label="justified" disabled>
                                        <FormatAlignJustifyIcon />
                                    </ToggleButton>
                                    <Divider flexItem orientation="vertical" className={classes.divider} />
                                    <ToggleButton value="bold" aria-label="bold">
                                        <FormatBoldIcon />
                                    </ToggleButton>
                                    <ToggleButton value="italic" aria-label="italic">
                                        <FormatItalicIcon />
                                    </ToggleButton>
                                    <ToggleButton value="underlined" aria-label="underlined">
                                        <FormatUnderlinedIcon />
                                    </ToggleButton>
                                    <ToggleButton value="color" aria-label="color" disabled>
                                        <FormatColorFillIcon />
                                        <ArrowDropDownIcon />
                                    </ToggleButton>
                                </ToggleButtonGroup><br />
                                <Typography variant="h5" style={{fontFamily:"serif"}}><i><b>Enter the date</b></i></Typography>
                                <TextareaAutosize 
                                aria-label="empty textarea" 
                                placeholder="Enter the date" 
                                className={classes.textarea} 
                                value={this.state.date}
                                onChange={(e)=>{this.setState({date:e.target.value})}}
                                /><br />
                                <Typography variant="h5" style={{fontFamily:"serif"}}><i><b>Enter the title</b></i></Typography>
                                 <TextareaAutosize 
                                aria-label="empty textarea" 
                                placeholder="Enter the title" 
                                className={classes.textarea} 
                                value={this.state.title}
                                onChange={(e)=>{this.setState({title:e.target.value})}}
                                /><br />
                                <Typography variant="h5" style={{fontFamily:"serif"}}><i><b>Write Your Note</b></i></Typography>
                                 <TextareaAutosize 
                                aria-label="empty textarea" 
                                placeholder="Write your note" 
                                className={classes.textarea} 
                                value={this.state.text}
                                onChange={(e)=>{this.setState({text:e.target.value})}}
                                />
                            </CardContent>
                        </Card> */}