import React from 'react';
export default class Help extends React.Component{
    render(){
        return(
            <div>
                
            </div>
        )
    }
}