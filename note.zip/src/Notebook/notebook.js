import React, { Component } from 'react';
import { withStyles } from "@material-ui/core/styles";
import {
    Drawer, AppBar, CssBaseline, Toolbar, Tooltip, Checkbox, List, Typography, Grid, TextField, DialogActions, Divider, MenuItem, ListItem, Icon, DialogContent, Dialog, Fab, DialogTitle, Card, CardContent, Button, IconButton, Menu, CardActions, Container
} from "@material-ui/core";
import AddIcon from '@material-ui/icons/Add';
import CloseIcon from '@material-ui/icons/Close';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import ReactHtmlParser from 'react-html-parser';
import Alert from '@material-ui/lab/Alert';
import MenuIcon from '@material-ui/icons/Menu';
import SpeedDial from '@material-ui/lab/SpeedDial';
import SpeedDialIcon from '@material-ui/lab/SpeedDialIcon';
import EditIcon from '@material-ui/icons/Edit';
import { Redirect } from 'react-router-dom';
import cover from "../Images/back.jpg";
import prof from "../Images/prof.webp";


const drawerWidth = 240;

const styles = theme => ({
    root: {
        display: 'flex',
    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        background: "black"
    },
    drawer: {
        width: drawerWidth,
        flexShrink: 0,
    },
    drawerPaper: {
        width: drawerWidth,
    },
    drawerContainer: {
        overflow: 'auto',
    },
    content: {
        flexGrow: 1,
        padding: theme.spacing(3),
    },
    fab: {
        position: 'absolute',
        marginLeft: 160,
        marginTop: 680
    },
    appbar: {
        position: 'relative',
        background: "grey",
        color: "white"
    },
    title: {
        marginLeft: theme.spacing(2),
        flex: 1,
    },
    textarea: {
        width: 1400,
    },
    speedDial: {
        position: 'absolute',
        bottom: theme.spacing(2),
        right: theme.spacing(2),
        color: "white"
    },
});
// const classes = useStyles();

class Notebook extends Component {
    constructor(props) {
        super(props);
        this.state = {
            dialog: false,
            left: "left",
            text: "",
            title: "",
            date: "",
            note: [],
            menu: false,
            anchorEl: null,
            dialogBox: false,
            change: false,
            em: this.props.location.state.ver_email,
            name: "",
            password: "",
            number: "",
            dialogname: false,
            dialognameopen: false,
            dialognameerror: false,
            dialogepassword: false,
            dialogepasswordopen: false,
            dialogepassworderror: false,
            dialognumber: false,
            dialognumberopen: false,
            dialognumbererror: false,
            object: localStorage.getItem("object")?JSON.parse(localStorage.getItem("object")): [],
            notebook: [],
            subject: "",
            dialogpush: false,
            dialogpushopen: false,
            dialogpusherror: false,
            open_delete: false,
            delete_id: "",
            open_new: false,
            signup: false,
            signin: false,
            searchData: "",
            usertoken: [],
            note_dialog: false,
            note_id: "",
            about_open: false,
            sdata: "",
            profile: false,
            prof: [],
            profileImage: "",
            uploadedFile: null,
            value: ""
        }
    }

    componentDidMount(e) {
        // console.log( this.props.ver_email);
        console.log(this.props.location.state.ver_email);
        if (this.state.searchData === "") {
            return;

        } else {
            // this.handleGetData();
            localStorage.getItem("object") && this.setState({
                object: JSON.parse(localStorage.getItem("object")),
            })
        }
    }

    userToken = () => {
        localStorage.getItem("user-token") && this.setState({
            usertoken: JSON.parse(localStorage.getItem("user-token")),
        })
    }

    handleChange = (e, editor) => {
        const data = editor.getData();
        this.setState({
            note: data
        })
    }
    handleUpdate = (e, editor) => {
        const data = editor.getData();
        this.setState({
            note_paragraph: data
        })
    }
    //FUNCTION CALL TO CHANGE NAME
    handleChangeName = () => {
        fetch("http://localhost:5000/update_name", {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'user-token': this.state.usertoken,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "email": this.state.em,
                "name": this.state.name
            })
        })
            .then(res => res.json())
            .then((resJson) => {
                if (resJson.status === true) {
                    this.setState({
                        dialogname: true,
                        message: resJson.message,
                        dialognameopen: false
                    })
                } else {
                    this.setState({
                        dialognameerror: true,
                        message: resJson.message

                    })
                }
            }
            )
    }

    //FUNCTION CALL TO CHANGE PASSWORD
    handleChangePassword = () => {
        fetch("http://localhost:5000/update_password", {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'user-token': this.state.usertoken,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "email": this.state.em,
                "password": this.state.password
            })
        })
            .then(res => res.json())
            .then((resJson) => {
                if (resJson.status === true) {
                    this.setState({
                        dialogepassword: true,
                        message: resJson.message,
                        dialogepasswordopen: false
                    })
                } else {
                    this.setState({
                        dialogepassworderror: true,
                        message: resJson.message

                    })
                }
            }
            )
    }

    //FUNCTION CALL TO CHANGE NUMBER
    handleChangeNumber = () => {
        fetch("http://localhost:5000/update_number", {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'user-token': this.state.usertoken,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "email": this.state.em,
                "phone_number": this.state.number
            })
        })
            .then(res => res.json())
            .then((resJson) => {
                if (resJson.status === true) {
                    this.setState({
                        dialognumber: true,
                        message: resJson.message,
                        dialognumberopen: false
                    })
                } else {
                    this.setState({
                        dialognumbererror: true,
                        message: resJson.message

                    })
                }
            }
            )
    }

    //FUNCTION CALL TO GET DATA
    handleGetData = (val) => {
        if (this.state.object === []) {
            alert('Please Create a note');
            return;
        }
        else {
            this.setState({
                sdata: "sdata"
            })
            fetch("http://localhost:5000/get_notes", {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'user-token': this.state.usertoken,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    "email": this.state.em,
                })
            })
                .then(res => res.json())
                .then((resJson) => {
                    localStorage.setItem("object",JSON.stringify(this.state.object));
                    this.setState({
                        object: resJson.result,
                        searchData: "",
                        val: ""

                    })
                    console.log(resJson.result);
                }
                )
        }
        console.log(this.state.object);

    }

    //FUNCTION CALL TO GET PROFILE
    handleGet = () => {
        fetch("http://localhost:5000/getusers", {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'user-token': this.state.usertoken,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "email": this.state.em,
            })
        })
            .then(res => res.json())
            .then((resJson) => {
                console.log(resJson.result);
                this.setState({
                    prof: resJson.result,
                    open: false,
                    profile: true,
                    // profileImage:resJson.result[0].profileImage.name

                })
                console.log(this.state.prof)
                console.log(this.state.profileImage)
            }
            )
    }


    //FUNCTION CALL TO PUSH DATA
    handlePush = () => {
        fetch("http://localhost:5000/push", {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'user-token': this.state.usertoken,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "email": this.state.em,
                "subject": this.state.subject,
                "paragraph": this.state.note
            })
        })
            .then(res => res.json())
            .then((resJson) => {
                if (resJson.status === true) {
                    this.handleGetData();
                    this.setState({
                        dialogpushopen: true,
                        dialogpush: false,
                        message: resJson.message,
                    })
                } else {
                    this.setState({
                        dialogpusherror: true,
                        message: resJson.message

                    })
                }
            }
            )
    }

    //FUNCTION CALL TO PULL DATA
    handleDelete = () => {
        console.log(this.state.delete_id);
        fetch("http://localhost:5000/pull", {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'user-token': this.state.usertoken,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "email": this.state.em,
                "id": this.state.delete_id
            })
        })
            .then(res => res.json())
            .then((resJson) => {
                if (resJson.status === true) {
                    this.handleGetData();
                    this.setState({
                        open_delete: false
                    })
                } else {
                    this.setState({
                        open_delete: true,
                        message: resJson.message

                    })
                }
            }
            )
    }

    //FUNCTION CALL TO DELETE ACCOUNT PERMANENTLY
    handleDeleteAccount = () => {
        fetch("http://localhost:5000/delete_user_permanently", {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'user-token': this.state.usertoken,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "email": this.state.em
            })
        })
            .then(res => res.json())
            .then((resJson) => {
                if (resJson.status === true) {
                    this.setState({
                        signup: true
                    })
                }
            }
            )
    }


    //FUNCTION CALL TO UPDATE NOTES
    handleUpdateNote = (note_id, note_subject, note_paragraph) => {
        fetch("http://localhost:5000/update_note", {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'user-token': this.state.usertoken,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "email": this.state.em,
                "id": this.state.note_id,
                "subject": this.state.note_subject,
                "paragraph": this.state.note_paragraph
            })
        })
            .then(res => res.json())
            .then((resJson) => {
                if (resJson.status === true) {
                    this.handleGetData();
                    this.setState({
                        dialog_note_messege: true,
                        message: resJson.message,
                        dialog_save: false
                    })
                } else {
                    this.setState({
                        dialog_error_message: true,
                        message: resJson.message,
                        dialog_save: false
                    })
                }
            }
            )
    }


    logout = () => {
        localStorage.clear();
        window.location.href = '/';
    }
    changeProfileImage = (event) => {
        this.setState({
            profileImage: event.target.files[0]
        })
        console.log(event.target.files[0]);
    }

    updateProfileHandler = () => {
        // e.preventDefault();
        const formData = new FormData();
        formData.append("email", this.state.em);
        formData.append("profileImage", this.state.profileImage);
        fetch("http://localhost:5000/profile", {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then((resJson) => {
                console.log(resJson);
                this.setState({
                    // profileImage:resJson.result.data
                })
            })

    }




    gotoFirst = () => {
        if (this.state.value === "") {
            alert('Please Choose');
            return;
        }
        let arrfirst = []
        arrfirst = this.state.object;
        let arrfirstfilter = arrfirst.filter(arrf => arrf.subject !== this.state.value);
        let removeElement = arrfirst.filter(arrf => arrf.subject === this.state.value);
        arrfirstfilter.splice(0, 0, removeElement[0]);
        localStorage.removeItem("object");
        localStorage.setItem("object", JSON.stringify(arrfirstfilter));
        this.setState({
            object: arrfirstfilter,
            value: ""
        },function(){
            // localStorage.removeItem("object");
            // localStorage.setItem("object", JSON.stringify(this.state.object));
        })

    }
    gotoLast = () => {
        if (this.state.value === "") {
            alert('Please Choose');
            return;
        }
        let arrLast = []
        arrLast = this.state.object;
        console.log("state value" + this.state.value)
        console.log(arrLast)
        let arrLastFilter = arrLast.filter(arrf => arrf.subject !== this.state.value);
        let removeElement = arrLast.filter(arrf => arrf.subject === this.state.value);
        arrLastFilter.push(removeElement[0]);
        localStorage.removeItem("object");
        localStorage.setItem("object", JSON.stringify(arrLastFilter));
        this.setState({
            object: arrLastFilter,
            value: ""
        },function(){
            // localStorage.removeItem("object");
            // localStorage.setItem("object", JSON.stringify(this.state.object));
        })

    }

    gotoUp = () => {
        if (this.state.value === "") {
            alert('Please Choose');
            return;
        }
        let upArr = []
        upArr = this.state.object;
        let upFilArr = upArr.filter(arrf => arrf.subject !== this.state.value);
        let removeElement = upArr.filter(arrf => arrf.subject === this.state.value);
        let index = upArr.findIndex(element => {
            if (element.subject === this.state.value) {
                return true;
            }
        });
        if (index === 0) {
            alert("Cannot be Placed To Up");
            this.setState({
            })
            return;
        }
        upFilArr.splice(index - 1, 0, removeElement[0]);
        localStorage.removeItem("object");
        localStorage.setItem("object", JSON.stringify(upFilArr));
        this.setState({
            object: upFilArr,
            value: ""
        },function(){
            // localStorage.removeItem("object");
            // localStorage.setItem("object", JSON.stringify(this.state.object));
        })

    }

    gotoDown = () => {
        if (this.state.value === "") {
            alert('Please Choose');
            return;
        }
        let downArr = []
        downArr = this.state.object;
        let downfilArr = downArr.filter(arrf => arrf.subject !== this.state.value);
        let removeElement = downArr.filter(arrf => arrf.subject === this.state.value);
        let index = downArr.findIndex(element => {
            if (element.subject === this.state.value) {
                return true;
            }
        });
        if (index === -1) {
            alert("Cannot be Placed To Down");
            return;
        }
        downfilArr.splice(index + 1, 0, removeElement[0]);
        localStorage.removeItem("object");
        localStorage.setItem("object", JSON.stringify(downfilArr));
        this.setState({
            object: downfilArr,
            value: ""
        },function(){
           
        })

    }

    render() {
        if (this.state.signup === true) {
            return (
                <div>
                    <Redirect to="signup" />
                </div>
            )
        }
        if (this.state.signin === true) {
            return (
                <div>
                    <Redirect to="/" />
                </div>
            )
        }
        const { classes } = this.props;

        var pp = this.state.profileImage;
        if (this.state.profileImage) {
            var pp = this.state.profileImage;
        } else {
            pp = prof;
        }

        return (
            <div className={classes.root}>
                <CssBaseline />
                {/* APP BAR */}
                <AppBar position="fixed" className={classes.appBar}>
                    <Toolbar>
                        <Typography variant="h3" noWrap style={{ fontFamily: "serif" }}>
                            <i>Notebook</i>
                        </Typography>
                        <Tooltip title="Go to First position" >
                            <IconButton style={{ marginLeft: 730, color: "white" }} onClick={this.gotoFirst}>
                                <Icon>
                                    first_page
                                    </Icon>
                            </IconButton>
                        </Tooltip>
                        <Tooltip title="Go to Previous position">
                            <IconButton style={{ color: "white" }} onClick={this.gotoUp}>
                                <Icon>
                                    arrow_upward
                                    </Icon>
                            </IconButton>
                        </Tooltip>
                        <Tooltip title="Go to Next poition">
                            <IconButton style={{ color: "white" }} onClick={this.gotoDown}>
                                <Icon>
                                    arrow_downward
                                    </Icon>
                            </IconButton>
                        </Tooltip>
                        <Tooltip title="Go to Last position">
                            <IconButton style={{ color: "white" }} onClick={this.gotoLast}>
                                <Icon>
                                    last_page
                                    </Icon>
                            </IconButton>
                        </Tooltip>
                        <Tooltip title="Search the Subject">
                            <input type="text" onChange={(e) => this.setState({ searchData: e.target.value })} style={{ height: 30, width: 300, borderRadius: 10 }} placeholder="Search the subject" />
                        </Tooltip>
                        <MenuIcon fontSize="large" style={{ marginLeft: 30 }} onClick={(e) => { this.setState({ open: true, anchorEl: e.currentTarget }) }} />
                        <Menu
                            id="lock-menu"
                            anchorEl={this.state.anchorEl}
                            keepMounted
                            open={this.state.open}
                            onClose={() => { this.setState({ open: false }) }}>
                            <MenuItem onClick={this.handleGet}><Typography style={{ fontFamily: "serif" }}>My Profile</Typography></MenuItem>
                            <MenuItem onClick={() => { this.setState({ open: false, change: true }) }}><Typography style={{ fontFamily: "serif" }}>Manage Account</Typography></MenuItem>
                            <MenuItem onClick={this, this.logout}><Typography style={{ fontFamily: "serif" }}>Log Out</Typography></MenuItem>
                            <MenuItem onClick={() => { this.setState({ account_open: true, open: false }) }}><Typography style={{ fontFamily: "serif" }}>Delete Account</Typography></MenuItem>
                            <MenuItem onClick={() => { this.setState({ about_open: true, open: false }) }}><Typography style={{ fontFamily: "serif" }}>About</Typography></MenuItem>
                        </Menu>
                        {/* () => { this.setState({ open: false, signin:true }) } */}
                    </Toolbar>
                </AppBar>
                <Drawer
                    className={classes.drawer}
                    variant="permanent"
                    classes={{
                        paper: classes.drawerPaper,
                    }}
                >
                    <Toolbar />
                    <div className={classes.drawerContainer}>
                        <List >
                            <Tooltip title="See all Notes">
                                <ListItem style={{ height: 50, fontFamily: "serif", cursor: "pointer" }} onClick={(val) => this.handleGetData(val)}>All Notes</ListItem>
                            </Tooltip>
                            {/* <ListItem style={{ height: 50, fontFamily: "serif", cursor:"pointer"  }} onClick={(val=>{if(this.state.object===[]){alert("please create a note first"); return;}else{this.handleGetData(val)}})}> All Notes</ListItem> */}
                            <Divider />
                        </List>
                    </div>
                    <Fab className={classes.fab} style={{ background: "black", color: "white" }} aria-label="add" onClick={() => { this.setState({ dialog: true }) }}>
                        <Tooltip title="Create a Note">
                            <AddIcon />
                        </Tooltip>
                    </Fab>
                </Drawer>

                {/* MAIN PART */}
                <main className={classes.content}>
                    <Toolbar />
                    <div>
                        {this.state.sdata === "" ? <Typography variant="h3" style={{ textAlign: "center", fontFamily: "serif", marginTop: 200 }}><i><b>Create Your First Note By Clicking on the Plus button if you have visited for the first time Or If you have already created any note then click on the All Notes to see the notes</b></i></Typography> : <ol>
                            {this.state.object === [] ? alert("please create a note first") :
                                this.state.object.filter((val) => {
                                    if (this.state.searchData === "") {
                                        return "No result found"
                                    } else if (val.subject.toLowerCase().includes(this.state.searchData.toLowerCase())) {
                                        return val
                                    }
                                }).map((s, index) => {
                                    return (
                                        <div>
                                            <Card key={s.id} style={{ width: 1200 }}>
                                                <CardContent>
                                                    <Typography variant="h6" style={{ fontFamily: "serif" }}><i>{s.subject}</i></Typography>
                                                    <CardActions>
                                                        <Tooltip title="Open Note">
                                                            <IconButton onClick={() => { this.setState({ sub: s.subject, para: s.paragraph, open_new: true }) }} style={{ marginLeft: 950 }}><Icon>open_in_new</Icon></IconButton>
                                                        </Tooltip>
                                                        <Tooltip title="Edit Note">
                                                            <IconButton onClick={() => { this.setState({ note_id: s.unique_id, note_paragraph: s.paragraph, note_subject: s.subject, note_dialog: true }) }}><Icon>edit</Icon></IconButton>
                                                        </Tooltip>
                                                        <Tooltip title="Delete Note">
                                                            <IconButton onClick={() => { this.setState({ delete_id: s.unique_id, open_delete: true }) }}><Icon>delete</Icon></IconButton>
                                                        </Tooltip>
                                                        <Tooltip title="Click to Change the position">
                                                            <Checkbox value={this.state.value}
                                                                onClick={(e) => { if (e.target.checked === true) { this.setState({ value: s.subject }) } }}
                                                            />
                                                        </Tooltip>
                                                    </CardActions>

                                                </CardContent>
                                            </Card><br />
                                        </div>
                                    )
                                })}
                        </ol>}
                    </div>


                    {/* AFTER CLICKING ON MY PROFILE BUTTON */}
                    <Dialog open={this.state.profile} fullScreen>
                        <DialogContent>
                            <AppBar className={classes.appbar}>
                                <Toolbar>
                                    <IconButton edge="start" color="inherit" onClick={() => { this.setState({ profile: false }) }} aria-label="close">
                                        <CloseIcon />
                                    </IconButton>
                                    <Typography variant="h3" className={classes.title} style={{ fontFamily: "serif", textAlign: "center" }}>
                                        <i>My Profile</i>
                                    </Typography>
                                </Toolbar>
                            </AppBar>
                            <div style={{ background: "url(" + cover + ")", backgroundSize: "cover", height: "70vh", width: "97vw" }}>
                                {this.state.prof.map((s) => {
                                    return (
                                        <div>
                                            <Container style={{ paddingTop: 70, height: 300, width: 1000 }}>
                                                <Card style={{ height: 550, width: 1000, background: "lightgrey" }}>
                                                    <CardContent>
                                                        <Grid container>
                                                            <Grid item lg={6} style={{ marginLeft: 30, marginTop: 30 }}>
                                                                <img src={pp} alt="profileImage" width="350" style={{ borderRadius: 20 }} />
                                                                {/* <Card style={{ background: "url(" + prof + ")", backgroundSize: "cover", height: 350, width: 350, borderRadius: 20, backgroundColor: "black" }}></Card> */}
                                                            </Grid><br />
                                                            <Grid item lg={6} style={{ marginLeft: -50, marginTop: 30 }}>
                                                                <Typography variant="h4" style={{ fontFamily: "serif" }}><i><b>Full Name</b></i></Typography>
                                                                <Typography variant="h5" style={{ fontFamily: "serif" }}><i>{s.name}</i></Typography><br />
                                                                <Typography variant="h4" style={{ fontFamily: "serif" }}><i><b>Email Id</b></i></Typography>
                                                                <Typography variant="h5" style={{ fontFamily: "serif" }}><i>{s.email}</i></Typography><br />
                                                                <Typography variant="h4" style={{ fontFamily: "serif" }}><i><b>Phone number</b></i></Typography>
                                                                <Typography variant="h5" style={{ fontFamily: "serif" }}><i>{s.phone_number}</i></Typography><br />
                                                                <Typography variant="h4" style={{ fontFamily: "serif" }}><i><b>Id</b></i></Typography>
                                                                <Typography variant="h5" style={{ fontFamily: "serif" }}><i>{s._id}</i></Typography>

                                                            </Grid>
                                                        </Grid>
                                                        <form
                                                        // action="/profile" method="post" enctype="multipart/form-data"
                                                        >
                                                            {/* <input type="file" name="profileImage" style={{ width: 300, marginLeft: 100, marginTop: 20 }} /> */}
                                                            <input type="file" style={{ width: 300, marginLeft: 100, marginTop: 20 }} onChange={this.changeProfileImage.bind(this)} />
                                                        </form>
                                                        {/* <input type="file" name="profileImage" style={{ width: 300, marginLeft: 100, marginTop: 20 }}/><br /> */}
                                                        <Button variant="outlined" size="large" style={{ width: 300, marginLeft: 150, marginTop: 20, borderRadius: 20 }} onClick={this.updateProfileHandler.bind(this)} ><Typography style={{ fontFamily: "serif" }}><i>Upload Profile</i></Typography></Button>
                                                        <Button variant="outlined" size="large" style={{ width: 300, marginLeft: 50, marginTop: 20, borderRadius: 20 }} onClick={() => { this.setState({ change: true }) }}><Typography style={{ fontFamily: "serif" }}><i>Edit Profile</i></Typography></Button>
                                                    </CardContent>
                                                </Card>

                                            </Container>
                                        </div>
                                    )

                                })}
                            </div>

                        </DialogContent>
                    </Dialog>


                    {/* AFTER CLICKING ON OPEN ICON BUTTON */}
                    <Dialog open={this.state.open_new} onClose={() => { this.setState({ dialog: false }) }} fullScreen>
                        <DialogContent>
                            <AppBar className={classes.appbar}>
                                <Toolbar>
                                    <IconButton edge="start" color="inherit" onClick={() => { this.setState({ open_new: false }) }} aria-label="close">
                                        <CloseIcon />
                                    </IconButton>
                                    <Typography variant="h3" className={classes.title} style={{ fontFamily: "serif", textAlign: "center" }}>
                                        <i>{this.state.sub}</i>
                                    </Typography>
                                </Toolbar>
                            </AppBar>
                            <div>
                                <Typography variant="h6" style={{ fontFamily: "serif", textAlign: "center" }}><i>{ReactHtmlParser(this.state.para)}</i></Typography>
                            </div>

                        </DialogContent>
                    </Dialog>


                    {/* AFTER CLICKING ON DELETE ICON BUTTON */}
                    <Dialog open={this.state.open_delete} aria-labelledby="form-dialog-title" fullWidth>
                        <DialogTitle id="form-dialog-title"><Typography variant='h5' style={{ fontFamily: "Serif" }}>DELETE ONE OBJECT</Typography></DialogTitle>
                        <DialogContent>
                            <Typography style={{ fontFamily: "Serif", color: "grey" }}>Are you sure you want to delete this?</Typography>
                        </DialogContent>
                        <DialogActions>
                            <Button onClick={() => { this.setState({ open_delete: false }) }} variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                CANCEL
                            </Button>
                            <Button onClick={this.handleDelete} variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                DELETE
                            </Button>
                        </DialogActions>
                        {this.state.message}
                    </Dialog>

                    {/* <SpeedDial
                        ariaLabel="SpeedDial openIcon example"
                        className={classes.speedDial}
                        onClick={() => { this.setState({ dialog: true }) }}
                        // hidden={hidden}
                        icon={<SpeedDialIcon openIcon={<EditIcon />} />}
                        // onClose={handleClose}
                        // onOpen={handleOpen}
                        // open={open}
                    ></SpeedDial> */}

                </main>


                {/* DIALOG BOX TO WRITE A NOTE*/}
                <Dialog open={this.state.dialog} onClose={() => { this.setState({ dialog: false }) }} fullScreen>
                    <DialogContent>
                        <AppBar className={classes.appbar}>
                            <Toolbar>
                                <IconButton edge="start" color="inherit" onClick={() => { this.setState({ dialog: false }) }} aria-label="close">
                                    <CloseIcon />
                                </IconButton>
                                <Typography variant="h3" className={classes.title} style={{ fontFamily: "serif" }}>
                                    <i>Create Your Note</i>
                                </Typography>
                                <Button autoFocus color="inherit" onClick={() => { this.setState({ dialogpush: true }) }} >
                                    save
                             </Button>
                            </Toolbar>
                        </AppBar>
                        <Typography variant="h4" style={{ fontFamily: "serif" }}><i>Subject</i></Typography>
                        <TextField
                            variant="filled"
                            color="primary"
                            label="Enter Your Subject Name"
                            required={true}
                            margin="dense"
                            value={this.state.subject}
                            onChange={(e) => { this.setState({ subject: e.target.value }) }}
                            fullWidth
                        />
                        <CKEditor
                            editor={ClassicEditor}
                            data={this.state.addData}
                            onChange={this.handleChange}

                        />
                    </DialogContent>
                </Dialog>

                {/* AFTER CLICKING ON SAVE BUTTON */}
                <Dialog open={this.state.dialogpush} fullWidth>
                    <Card>
                        <CardContent>
                            <DialogTitle>
                                <Typography variant="h4" style={{ fontFamily: "serif" }}><i>Notebook</i></Typography>
                            </DialogTitle>
                            <DialogContent>
                                <Typography style={{ fontFamily: "serif" }}>Do you want to save it?</Typography>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => { this.setState({ dialogpush: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    Cancel
                                </Button>
                                <Button onClick={this.handlePush} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    Save
                                </Button>
                            </DialogActions>
                        </CardContent>
                    </Card>
                </Dialog>

                {/* AFTER CLICKING ON OK BUTTON TO SAVE */}
                <Dialog open={this.state.dialogpusherror} fullWidth >
                    <Card>
                        <CardContent>
                            <DialogContent >
                                <Alert severity="info">{this.state.message}</Alert>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => { this.setState({ dialogpusherror: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    OK
                                </Button>
                            </DialogActions>
                        </CardContent>
                    </Card>

                </Dialog>
                <Dialog open={this.state.dialogpushopen} fullWidth>
                    <Card style={{ background: "darkgrey" }}>
                        <CardContent>
                            <DialogContent>
                                <Alert severity="success">{this.state.message}</Alert>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => { this.setState({ dialogpushopen: false, dialog: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    OK
                                </Button>
                            </DialogActions>
                        </CardContent>
                    </Card>

                </Dialog>


                {/* DIALOG BOX TO UPDATE A NOTE*/}
                <Dialog open={this.state.note_dialog} fullScreen>
                    <DialogContent>
                        <AppBar className={classes.appbar}>
                            <Toolbar>
                                <IconButton edge="start" color="inherit" onClick={() => { this.setState({ note_dialog: false }) }} aria-label="close">
                                    <CloseIcon />
                                </IconButton>
                                <Typography variant="h3" className={classes.title} style={{ fontFamily: "serif" }}>
                                    <i>Edit Your Note</i>
                                </Typography>
                                <Button autoFocus color="inherit" onClick={() => { this.setState({ dialog_save: true }) }} >
                                    save
                             </Button>
                            </Toolbar>
                        </AppBar>
                        <Typography variant="h4" style={{ fontFamily: "serif" }}><i>Subject</i></Typography>
                        <TextField
                            variant="filled"
                            color="primary"
                            label="Enter Your Subject Name"
                            required={true}
                            margin="dense"
                            value={this.state.note_subject}
                            onChange={(e) => { this.setState({ note_subject: e.target.value }) }}
                            fullWidth
                        />
                        <CKEditor
                            editor={ClassicEditor}
                            data={this.state.addData}
                            data={this.state.note_paragraph}
                            onChange={this.handleUpdate}

                        />
                    </DialogContent>
                </Dialog>




                {/* AFTER CLICKING ON SAVE BUTTON OF UPDATE NOTES*/}
                <Dialog open={this.state.dialog_save} fullWidth>
                    <Card>
                        <CardContent>
                            <DialogTitle>
                                <Typography variant="h4" style={{ fontFamily: "serif" }}><i>Notebook</i></Typography>
                            </DialogTitle>
                            <DialogContent>
                                <Typography style={{ fontFamily: "serif" }}>Do you want to save the updated note?</Typography>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => { this.setState({ dialog_save: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    Cancel
                                </Button>
                                <Button onClick={this.handleUpdateNote} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    Save
                                </Button>
                            </DialogActions>
                        </CardContent>
                    </Card>
                </Dialog>

                {/* AFTER CLICKING ON OK BUTTON TO UPDATE */}
                <Dialog open={this.state.dialog_error_message} fullWidth >
                    <Card>
                        <CardContent>
                            <DialogContent >
                                <Alert severity="info">{this.state.message}</Alert>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => { this.setState({ dialog_error_message: false, dialog_save: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    OK
                                </Button>
                            </DialogActions>
                        </CardContent>
                    </Card>

                </Dialog>
                <Dialog open={this.state.dialog_note_messege} fullWidth>
                    <Card style={{ background: "darkgrey" }}>
                        <CardContent>
                            <DialogContent>
                                <Alert severity="success">{this.state.message}</Alert>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => { this.setState({ dialog_note_messege: false, dialog_save: false, note_dialog: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    OK
                                </Button>
                            </DialogActions>
                        </CardContent>
                    </Card>

                </Dialog>



                {/* DIALOG BOX AFTER CLICKING ON MANAGE ACCOUNT */}
                <Dialog open={this.state.change} fullWidth>
                    <Card>
                        <CardContent>
                            <DialogTitle >
                                <Typography variant="h4" style={{ fontFamily: "serif" }}>
                                    <i><b>Manage Your Account</b></i>
                                    <IconButton edge="end" color="inherit" onClick={() => { this.setState({ change: false }) }} aria-label="close" style={{ marginLeft: 160 }}>
                                        <CloseIcon />
                                    </IconButton>
                                </Typography>
                            </DialogTitle>
                            <DialogContent>
                                <MenuItem onClick={() => { this.setState({ dialognameopen: true, change: false }) }}><Typography style={{ fontFamily: "serif", fontSize: "18px" }}>Update Your Name</Typography></MenuItem>
                                <MenuItem onClick={() => { this.setState({ dialogepasswordopen: true, change: false }) }}><Typography style={{ fontFamily: "serif", fontSize: "18px" }}>Update Your Password</Typography></MenuItem>
                                <MenuItem onClick={() => { this.setState({ dialognumberopen: true, change: false }) }}><Typography style={{ fontFamily: "serif", fontSize: "18px" }}>Update Your Phone Number</Typography></MenuItem>
                            </DialogContent>
                        </CardContent>
                    </Card>
                </Dialog>

                {/* DIALOG BOX AFTER CLICKING ON CHANGE YOUR NAME */}
                <Dialog open={this.state.dialognameopen} fullWidth>
                    <Card>
                        <CardContent>
                            <DialogTitle >
                                <Typography variant="h4" style={{ fontFamily: "serif" }}>
                                    <i><b>Update Your Name</b></i>
                                </Typography>
                            </DialogTitle>
                            <DialogContent>
                                <Typography variant="h6" style={{ fontFamily: "serif" }}><i>Enter your name</i></Typography>
                                <TextField
                                    variant="outlined"
                                    // color="primary"
                                    label="Enter Your Name"
                                    required={true}
                                    margin="dense"
                                    value={this.state.name}
                                    onChange={(e) => { this.setState({ name: e.target.value }) }}
                                    fullWidth
                                />
                                <DialogActions>
                                    <Button
                                        variant="outlined"
                                        style={{ color: "black", background: "grey", fontFamily: "serif" }}
                                        margin="dense"
                                        size="large"
                                        onClick={() => { this.setState({ dialognameopen: false }) }}
                                        variant="outlined"
                                    >Cancel</Button>
                                    <Button
                                        variant="outlined"
                                        style={{ color: "black", background: "grey", fontFamily: "serif" }}
                                        margin="dense"
                                        size="large"
                                        onClick={this.handleChangeName}
                                        variant="outlined"
                                    >Update</Button>
                                </DialogActions>
                            </DialogContent>
                        </CardContent>
                    </Card>

                </Dialog>

                {/* DIALOG BOX AFTER CLICKING UPDATE BUTTON OF CHANGE YOUR NAME */}
                <Dialog open={this.state.dialognameerror} fullWidth >
                    <Card>
                        <CardContent>
                            <DialogContent >
                                <Alert severity="info">{this.state.message}</Alert>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => { this.setState({ dialognameerror: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    OK
                                </Button>
                            </DialogActions>
                        </CardContent>
                    </Card>

                </Dialog>
                <Dialog open={this.state.dialogname} fullWidth>
                    <Card style={{ background: "darkgrey" }}>
                        <CardContent>
                            <DialogContent>
                                <Alert severity="success">{this.state.message}</Alert>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => { this.setState({ dialogname: false, profile: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    OK
                                </Button>
                            </DialogActions>
                        </CardContent>
                    </Card>

                </Dialog>


                {/* DIALOG BOX AFTER CLICKING ON CHANGE PASSWORD */}
                <Dialog open={this.state.dialogepasswordopen} fullWidth>
                    <Card>
                        <CardContent>
                            <DialogTitle >
                                <Typography variant="h4" style={{ fontFamily: "serif" }}>
                                    <i><b>Update Your Email Id</b></i>
                                </Typography>
                            </DialogTitle>
                            <DialogContent>
                                <Typography variant="h6" style={{ fontFamily: "serif" }}><i>Enter your Password</i></Typography>
                                <TextField
                                    variant="outlined"
                                    // color="primary"
                                    label="Enter Your Name"
                                    required={true}
                                    margin="dense"
                                    value={this.state.password}
                                    onChange={(e) => { this.setState({ password: e.target.value }) }}
                                    fullWidth
                                />
                                <DialogActions>
                                    <Button
                                        variant="outlined"
                                        style={{ color: "black", background: "grey", fontFamily: "serif" }}
                                        margin="dense"
                                        size="large"
                                        onClick={() => { this.setState({ dialogepasswordopen: false }) }}
                                        variant="outlined"
                                    >Cancel</Button>
                                    <Button
                                        variant="outlined"
                                        style={{ color: "black", background: "grey", fontFamily: "serif" }}
                                        margin="dense"
                                        size="large"
                                        onClick={this.handleChangePassword}
                                        variant="outlined"
                                    >Update</Button>
                                </DialogActions>
                            </DialogContent>
                        </CardContent>
                    </Card>

                </Dialog>

                {/* DIALOG BOX AFTER CLICKING UPDATE BUTTON OF CHANGE YOUR PASSWORD */}
                <Dialog open={this.state.dialogepassworderror} fullWidth >
                    <Card>
                        <CardContent>
                            <DialogContent >
                                <Alert severity="info">{this.state.message}</Alert>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => { this.setState({ dialogepassworderror: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    OK
                                </Button>
                            </DialogActions>
                        </CardContent>
                    </Card>

                </Dialog>
                <Dialog open={this.state.dialogepassword} fullWidth>
                    <Card style={{ background: "darkgrey" }}>
                        <CardContent>
                            <DialogContent>
                                <Alert severity="success">{this.state.message}</Alert>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => { this.setState({ dialogepassword: false, profile: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    OK
                                </Button>
                            </DialogActions>
                        </CardContent>
                    </Card>

                </Dialog>


                {/* DIALOG BOX AFTER CLICKING ON CHANGE PHONE NUMBER */}
                <Dialog open={this.state.dialognumberopen} fullWidth>
                    <Card>
                        <CardContent>
                            <DialogTitle >
                                <Typography variant="h4" style={{ fontFamily: "serif" }}>
                                    <i><b>Update Your Email Id</b></i>
                                </Typography>
                            </DialogTitle>
                            <DialogContent>
                                <Typography variant="h6" style={{ fontFamily: "serif" }}><i>Enter your Password</i></Typography>
                                <TextField
                                    variant="outlined"
                                    // color="primary"
                                    label="Enter Your Name"
                                    required={true}
                                    margin="dense"
                                    value={this.state.number}
                                    onChange={(e) => { this.setState({ number: e.target.value }) }}
                                    fullWidth
                                />
                                <DialogActions>
                                    <Button
                                        variant="outlined"
                                        style={{ color: "black", background: "grey", fontFamily: "serif" }}
                                        margin="dense"
                                        size="large"
                                        onClick={() => { this.setState({ dialognumberopen: false }) }}
                                        variant="outlined"
                                    >Cancel</Button>
                                    <Button
                                        variant="outlined"
                                        style={{ color: "black", background: "grey", fontFamily: "serif" }}
                                        margin="dense"
                                        size="large"
                                        onClick={this.handleChangeNumber}
                                        variant="outlined"
                                    >Update</Button>
                                </DialogActions>
                            </DialogContent>
                        </CardContent>
                    </Card>

                </Dialog>

                {/* DIALOG BOX AFTER CLICKING UPDATE BUTTON OF CHANGE YOUR EMAIL ID */}
                <Dialog open={this.state.dialognumbererror} fullWidth >
                    <Card>
                        <CardContent>
                            <DialogContent >
                                <Alert severity="info">{this.state.message}</Alert>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => { this.setState({ dialognumbererror: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    OK
                                </Button>
                            </DialogActions>
                        </CardContent>
                    </Card>

                </Dialog>
                <Dialog open={this.state.dialognumber} fullWidth>
                    <Card style={{ background: "darkgrey" }}>
                        <CardContent>
                            <DialogContent>
                                <Alert severity="success">{this.state.message}</Alert>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={() => { this.setState({ dialognumber: false, profile: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                                    OK
                                </Button>
                            </DialogActions>
                        </CardContent>
                    </Card>

                </Dialog>

                {/* AFTER CLICKIN ON DELETE ACCOUNT */}
                <Dialog open={this.state.account_open} fullWidth>
                    <DialogTitle><Typography variant="h4" style={{ fontFamily: "serif" }}><i>Delete Account Permanently</i></Typography></DialogTitle>
                    <DialogContent>
                        <Typography variant="h6" style={{ fontFamily: "serif", color: "grey" }}><i>Are you sure you want to delete your account permanently?</i></Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => { this.setState({ account_open: false }) }} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                            Cancel
                        </Button>
                        <Button onClick={this.handleDeleteAccount} autoFocus variant="outlined" style={{ color: "black", background: "lightgrey", fontFamily: "serif" }}>
                            Delete Account
                        </Button>
                    </DialogActions>
                </Dialog>


                {/* AFTER CLICKING ON HELP */}
                <Dialog open={this.state.about_open} fullScreen>
                    <DialogContent>
                        <AppBar style={{ position: 'relative', background: "black", color: "white" }}>
                            <Toolbar>
                                <IconButton edge="start" color="inherit" onClick={() => { this.setState({ about_open: false }) }} aria-label="close">
                                    <CloseIcon />
                                </IconButton>
                                <Typography variant="h3" style={{ fontFamily: "serif", position: "center", color: "whitesmoke", marginLeft: 650 }}>
                                    <i>About</i>
                                </Typography>
                            </Toolbar>
                        </AppBar>
                        <div>
                            <Typography variant="h5" style={{ fontFamily: "serif", textAlign: "center", marginTop: 50 }}><i>Be more productive with this beautifully simple note-taking app. </i></Typography><br />
                            <Typography variant="h4" style={{ fontFamily: "serif", textAlign: "center" }}><i><b>TAKE NOTES</b></i></Typography>
                            <Typography variant="h5" style={{ fontFamily: "serif", textAlign: "center" }}><i>Notebook provides different ways to take notes and capture your thoughts.</i></Typography>
                            <Typography variant="h5" style={{ fontFamily: "serif", textAlign: "center" }}><i>* Write notes. Start with a text, add images, all in the same text note.</i></Typography>
                            <Typography variant="h5" style={{ fontFamily: "serif", textAlign: "center" }}><i>* Capture moments using the dedicated photo note.</i></Typography><br />
                            <Typography variant="h4" style={{ fontFamily: "serif", textAlign: "center" }}><i><b>ORGANIZE NOTES</b></i></Typography>
                            <Typography variant="h5" style={{ fontFamily: "serif", textAlign: "center" }}><i>Keep yourself and your work organized.</i></Typography>
                            <Typography variant="h5" style={{ fontFamily: "serif", textAlign: "center" }}><i>* Organize various notes into notebooks.</i></Typography>
                            <Typography variant="h5" style={{ fontFamily: "serif", textAlign: "center" }}><i>* Search within a notebook or across notebooks.</i></Typography>
                            <Typography variant="h5" style={{ fontFamily: "serif", textAlign: "center" }}><i>* Securely lock your note with passwords of your choice.</i></Typography><br />
                            <Typography variant="h4" style={{ fontFamily: "serif", textAlign: "center" }}><i><b>SYNCHRONIZE ACROSS DEVICES</b></i></Typography>
                            <Typography variant="h5" style={{ fontFamily: "serif", textAlign: "center" }}><i>Access your work anywhere and everywhere with Notebook's ability to sync your notes to the cloud.</i></Typography>
                            <Typography variant="h5" style={{ fontFamily: "serif", textAlign: "center" }}><i>* Synchronize all your notes and notebooks across devices and to the cloud.</i></Typography><br />



                        </div>

                    </DialogContent>
                </Dialog>




                {/* <Dialog open={this.state.dialogBox} onClose={()=>{this.setState({dialogBox:false})}}>
                    <DialogContent>
                    {ReactHtmlParser(this.state.note)}
                    </DialogContent>
                </Dialog> */}
            </div>


        )
    }
}

export default withStyles(styles, { withTheme: true })(Notebook);